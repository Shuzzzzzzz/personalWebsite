function toggleMenu() {
    let menu = document.querySelector(".menu-links");
    menu.classList.toggle("open");
    let icon = document.querySelector(".hamburger-icon");  
    icon.classList.toggle("open");
  }
